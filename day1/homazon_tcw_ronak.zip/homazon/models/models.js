var mongoose = require('mongoose');
// import mongoose from 'mongoose';
var connect = process.env.MONGODB_URI;
var Schema = mongoose.Schema;

mongoose.connect('mongodb://user:user@ds139352.mlab.com:39352/homazon_database');

var userSchema = new Schema({
  username: String,
  password: String,
});

var productSchema = new Schema({
  title: String,
  description: String,
  imageUri: String
});

var paymentSchema = new Schema({
  stripeBrand: String,
  stripeCustomerId: String,
  stripeExpMonth: Number,
  stripeExpYear: Number,
  stripeLast4: Number,
  stripeSource: String,
  status: Number,
  // Any other data you passed into the form
  _userid: mongoose.Schema.Types.ObjectId
});

var User = mongoose.model('User', userSchema);
var Product = mongoose.model('Product', productSchema);
var Payment = mongoose.model('Payment', paymentSchema);

module.exports = {
  User: User,
  Product: Product,
  Payment:Payment
};
// export default {
//   User: User
// }
