set -x MONGODB_URI mongodb://user:user@ds139352.mlab.com:39352/homazon_database
set -x PUBLISHABLE_KEY pk_test_44KoegP6vm6WJRxpWts7TAJn
set -x SECRET_KEY sk_test_6yg3O9QoRWkhvflbuH5lNmej
