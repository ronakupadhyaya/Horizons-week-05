/*jshint esversion: 6 */
var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var expressValidator = require('express-validator');
var models = require('../models/models');
var User = models.User;
var Product = models.Product;
var Payment = models.Payment;
var passport = require('passport');
import products from '/Users/tcw/horizons/week05/day1/homazon/seed/products.json';
import stripePackage from 'stripe';
const stripe = stripePackage('sk_test_6yg3O9QoRWkhvflbuH5lNmej');

router.use(expressValidator());


router.get('/temp', function(req, res) {
  var productPromises = products.map((product) => (new Product(product).save()));
  Promise.all(productPromises)
    .then(() => (console.log('Success. Created products!')))
    .catch((err) => (console.log('Error', err)));
});

/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });
router.get('/', (req, res, next) => {
  if (!req.session.cart) {
    req.session.cart = [];
  }
  Product.find().exec().then((products) => {
    res.render('index', {
      products: products,
      length: req.session.cart.length
    });
  });
});

router.get('/product/:pid', (req, res, next) => {
  Product.findById(req.params.pid).exec().then((product) => {
    res.render('product', {
      product: product
    });
  });
});


router.get('/signup', function(req, res) {
  res.render('signup');
});
router.post('/signup', function(req, res) {
  req.check('username', 'Username cannot be empty').notEmpty();
  req.check('password', 'Password cannot be empty').notEmpty();
  req.check('passwordRepeat', 'PasswordRepeat cannot be empty').notEmpty();
  req.check('passwordRepeat', 'Passwords do not match').equals(req.body.password);

  var err = req.validationErrors();
  if (err) {
    res.render('signup', {
      error: err
    });
  } else {
    var newUser = new User({
      username: req.body.username,
      password: req.body.password,
    });
    newUser.save(function(err, saved) {
      if (err) {
        res.render('signup', {
          error: err
        });
      }
      console.log("sucessful save", saved);
      res.redirect('login');
    });
  }
});
router.get('/login', function(req, res) {
  res.render('login');
});

router.get('/success', function(req, res) {
  res.render('success', {
    user: req.user.username
  });
});

router.post('/login', passport.authenticate('local', {
  successRedirect: '/',
  failureRedirect: '/login'
}));

router.get('/logout', function(req, res) {
  req.logout();
  res.redirect('/login');
});

router.get('/cart', (req, res) => {
  // Render a new page with our cart
  // var cart = req.session.cart;
  // var temp = cart.map(item => Product.findById(item.id));
  // Promise.all(temp).then(resp => {
  //   for (var i = 0; i < resp.length; i++) {
  //     resp[i].quantity = cart[i].quantity;
  //   }
  //   res.render('cart',{
  //     cart: resp
  //     });
  // });

  res.render('cart', {
    cart: req.session.cart
  });


});

router.post('/cart/add/:pid', (req, res, next) => {
  // Insert code that takes a product id (pid), finds that product
  // and inserts it into the cart array. Remember, we want to insert
  // the entire object into the array...not just the pid.

  Product.findById(req.params.pid).exec().then((product) => {
    req.session.cart.push(product);
    // console.log(req.session.cart);
    res.redirect('/cart');

  });

});

router.post('/cart/delete/:pid', (req, res, next) => {
  // Insert code that takes a product id (pid), finds that product
  // and removes it from the cart array. Remember that you need to use
  // the .equals method to compare Mongoose ObjectIDs.
  var cart = req.session.cart;
  for(var i = 0; i<cart.length; i++){
    if(cart[i]._id === req.params.pid){
      cart.splice(i, 1);
    }
  }
  // console.log("deleted");
  res.redirect('/cart');

});

router.post('/cart/delete', (req, res, next) => {
  // Empty the cart array
  req.session.cart = [];
  res.redirect('/cart');
});


router.post('/checkout', function(req, res){
  var token = req.body.stripeToken; // Using Express
  console.log(req.body);
  stripe.customers.create({
    email: "paying.user@example.com",
    source: token,
  }).then(function(customer) {
    // YOUR CODE: Save the customer ID and other info in a database for later.
    //console.log("Customer: ", customer);
    //console.log("Sources Data", customer.sources.data);


    return stripe.charges.create({
      amount: 1000,
      currency: "usd",
      customer: customer.id,
    });
  }).then(function(charge) {
    console.log('charge', charge);
    // Use and save the charge info.
    // var payment = new Payment({
    //   stripeBrand: customer.sources.data.brand,
    //   stripeCustomerId: customer.sources.data.customer,
    //   stripeExpMonth: customer.sources.data.exp_month,
    //   stripeExpYear: customer.sources.data.exp_year,
    //   stripeLast4: customer.sources.data.last4,
    //   stripeSource:
    // });
  });

  res.redirect('/');

  // YOUR CODE (LATER): When it's time to charge the customer again, retrieve the customer ID.
  // stripe.charges.create({
  //   amount: 1500, // $15.00 this time
  //   currency: "usd",
  //   customer: customerId,
  // });
});












module.exports = router;
