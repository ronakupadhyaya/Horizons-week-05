export MONGODB_URI="mongodb://jay:jay@ds141082.mlab.com:41082/homazon_demo"
export SECRET="whatever"
